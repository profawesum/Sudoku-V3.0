import Foundation


func CharacterPosition(_ pos: Int,_ from: String) -> Character
{
    let temp = from;
    let index = temp.index(temp.startIndex, offsetBy: pos);
    return (temp[index])
}

func DrawGrid(view: String)
{
    print(view)
    var i = 1;
    var once =  true;
    while ( i < 82)
    {
        if (view.count > i)
        {
            var temp = CharacterPosition(i, view);

            if (temp == "0")
            {
                temp = " ";
            }
            print(temp, terminator:"");
        }
        else 
        {
            print(" ", terminator:"");

        }
        if (once == true)
        {
            once = false;
        }
        else
        {
            if (i % 9 == 0)
            {
                print("");
            }
        }

        if (i % 9  == 3 || i % 9  == 6)
        {
           print("|" , terminator:""); 
        }
        if (i == 27 || i == 54)
        {
            print("-----------");
        }
        i+=1;
    }
}

func Menu() -> String
{
    system("cls") 
    print("1) manually enter numbers")
    print("2) automaticly generate numbers")
    let input1 = readLine()!

    if (input1 == "1")
    {
        var i = 0;
        var originalString = " ";        
        var originalString2 = " ";

        while (i < 9)
        {
            system("cls") 
            print("type the \(i + 1) th line (1-9 and 0 being blank)");
            var input2 = readLine()!

            while (input2.count < 9)
            {
                input2.append("0");
            }     
            originalString2.append(input2);
            system("cls") 

            DrawGrid(view: originalString2);
            print("\n1) redoline");
            if (i == 8)
            {
                print("2) Solve");
            }
            else
            {
                print("2) nextline");
            }
            let input3 = readLine()!
            if (input3 == "1")
            {
                originalString2 = originalString;
            }
            if (input3 == "2")
            {
                originalString = originalString2;
                i += 1;
            }

        }   
        return(originalString)

    }
    if (input1 == "2")
    {
        var originalString = ""
        print("1=ez 2=med 3=hard 4=ex 5= auto")
        let input4 = readLine()!
        if (input4 == "1")
        {
            originalString = " 501627000820090013640000000960401300080730429004900500006075030200369005050000190"
        }
        if (input4 == "2")
        {
            originalString = " 200000000000000000000000000000000000000000000000000000000000000000000000000000000"
        }
        if (input4 == "3")
        {
            originalString = " 000000008300000500004300091001046750049000010070005000000400060000081004005000073"
        }
        if (input4 == "4")
        {
            originalString = " 000030002000900830100700540080004000000050080470000306000060415009501060600000000"
        }
        if (input4 == "5")
        {
            originalString = AiString();
            print(originalString)
            let wait = readLine();
        }
        

        return(originalString)
    }

    return(input1)
}

func StringToArray(input: String) -> Array<Array<Int>>
{
    var ans = Array(repeating: Array(repeating: 0, count: 9), count: 9)
    var x = 0;
    var y = 0;
    var count = 1;
    
    while (y < 9)
    {
        while (x < 9)
        {
            let temp1 = String(CharacterPosition(count, input));
            let temp2 = Int(temp1)!
            ans[x][y] = (temp2);


            print(ans[x][y])
            count += 1;
            x += 1;
        }
        print("newline")
        x = 0;
        y += 1;
    }


    return(ans)
}

func AiString() -> String
{
    var tempgod = " "
    for i in 0..<81
    {
        tempgod.append("0")
    }

    var i = 1
    while (i < 10)
    {
        var seed = Int((Date().timeIntervalSinceReferenceDate * 10000000000 )) % 1000
        seed *= 7 * i
        seed =  seed % 81
        print(seed)
        var temp = Array(tempgod)
        temp[seed] = Character(UnicodeScalar(i + 48)!);
        tempgod = String(temp)
        i += 1
    }

    tempgod = Solve(input: StringToArray(input: tempgod))

    
    //Permutation

    var tempgod2 = Array(tempgod)

    var seed = Int((Date().timeIntervalSinceReferenceDate * 10000000000 )) % 100
         seed = Int((Date().timeIntervalSinceReferenceDate * 10000000000 )) % 100

    print(seed)
    seed *= 7
    print(seed)
    seed =  seed % 20 
    print(seed)

    seed += 40
    for i in 0..<seed
    {
        var seed1 = Int((Date().timeIntervalSinceReferenceDate * 10000000000 )) % 100
        print(seed1, "big boy")
        seed1 *= 7 * i
        print(seed1, "xi")

        seed1 =  seed1 % 81
                print(seed1, " %81")

        tempgod2[seed1] = "0"
        print(seed1, "finals")

    }    

    tempgod = String(tempgod2)

    DrawGrid(view : tempgod)
    //DrawGrid(view: tempgod)
    readLine()

    return(tempgod)
}

func ArrayToString(input: Array<Array<Int>>) -> String
{
    var ans = " "
    var x = 0 ;
    var y = 0;
    while (y < 9)
    {
        while (x < 9)
        {
            var temp1 = input[x][y];
            temp1 += 48;
            let temp2 = Character(UnicodeScalar(temp1)!);
            ans.append(temp2);
            x += 1;
        }
        x = 0;
        y += 1;
    }

    return(ans);
}

func RemoveZeroes(opt: Array<Int>) -> Array<Int>
{
    var tempOpt = opt
    var i = opt.count - 1 
    while (i > -1)
    {


        if (opt[i] == 0)
        {

            tempOpt.remove(at: i)
        }
        i -= 1
    }
    return(tempOpt)
}

func Solve(input: Array<Array<Int>>) -> (String)
{
    var input = input
    var difference = 0

    while (isSolved(input: input) != true)
    {
        var input1 = input
        var ans = Search(input: input)
        input = ans.0
        var i = 0

            if (ans.2.count == 0)
            {
                break;
            }
            system("cls") 
            DrawGrid(view: ArrayToString(input: input))


            if (input == input1)
            {
                difference += 1
            }
            else
            {
                difference = 0 
            }
            if (difference >= 2)
            {
                var tempdepth = Depth(input: input, ans: ans)
                if (tempdepth.1 == true)
                {
                    input = tempdepth.0;
                    break
                }
                difference = 0
                i += 1
            }
        
    }
    return(ArrayToString(input:input))
}


func Depth(input: Array<Array<Int>>, ans : (Array<Array<Int>>, Array<Int>, Array<Int>)) -> (input: Array<Array<Int>>, sucess: Bool)
{
    var input = input
    var i = 0
    var inputtemp = input
    var diff1 = 0


    while (i < ans.2.count)
    {
        inputtemp[ans.1[0]][ans.1[1]] = ans.2[i]
        var inputtemp1 = inputtemp
        var ans = Search(input: inputtemp)
        inputtemp = ans.0
        DrawGrid(view: ArrayToString(input: inputtemp))

        if (isSolved(input: inputtemp) == true)
        {
            return(inputtemp, true)
        }

        if (inputtemp == inputtemp1)
        {
            diff1 += 1
        }
        else
        {
            diff1 = 0
        }
        if (diff1 >= 2)
        {
            var tempdepth = Depth(input: inputtemp, ans: ans)
            if (tempdepth.1 == true)
            {
                return(tempdepth.0, true)
            }
            i += 1
            diff1 = 0
            inputtemp = input

        }
    }
    return(input, false)

}


func Search(input: Array<Array<Int>>) -> (input: Array<Array<Int>>, position: Array<Int>, shortesetPossible: Array<Int>)
{
    var input = input
    let possibility = [1,2,3,4,5,6,7,8,9]
    var possibilitytemp = possibility; 
    var possibilitytemp2 = possibility;
    var shortesetPossible = possibility;
    var shortestPosition = [0, 0]
    var x = 0;
    var y = 0;
    mainLoop: while (y < 9)
    {
        while (x < 9)
        {
            if (input[x][y] == 0)
            {
                var possibilitytemp = possibility; 
                possibilitytemp = QBoxCheck(input: input, X: x, Y: y, possibility: possibilitytemp)
                possibilitytemp2 = RemoveZeroes(opt: possibilitytemp)
                if (possibilitytemp2.count > 1)
                {
                    possibilitytemp = QVCheck(input: input, X: x, Y: y, possibility: possibilitytemp)
                    possibilitytemp2 = RemoveZeroes(opt: possibilitytemp)
                    if (possibilitytemp2.count > 1)
                    {
                        possibilitytemp = QHCheck(input: input, X: x, Y: y, possibility: possibilitytemp)
                        possibilitytemp2 = RemoveZeroes(opt: possibilitytemp)
                        print(possibilitytemp2)
                        if (possibilitytemp2.count > 1)
                        {
                            if (shortesetPossible.count > possibilitytemp2.count)
                            {
                                shortesetPossible = possibilitytemp2
                                shortestPosition = [x, y]
                            }

                        }
                        else if (possibilitytemp2.count == 0)
                        {
                            print("problem is unsolvable, 0 possible soultions at position: ", x, ", ",y)
                            shortesetPossible = possibilitytemp2
                            shortestPosition = [x, y]
                            break mainLoop;
                        }
                        else
                        {
                            shortesetPossible = possibilitytemp2
                            shortestPosition = [x, y]
                            input[x][y] = possibilitytemp2[0]
                            break mainLoop;
                        }
                    }
                    else if (possibilitytemp2.count == 0)
                    {
                       print("problem is unsolvable, 0 possible soultions at position: ", x, ", ",y)
                        shortesetPossible = possibilitytemp2
                        shortestPosition = [x, y]
                       break mainLoop;
                    }
                    else
                    {
                        shortesetPossible = possibilitytemp2
                        shortestPosition = [x, y]
                        input[x][y] = possibilitytemp2[0]
                        break mainLoop;
                    }
                }
                else if (possibilitytemp2.count == 0)
                {
                    print("problem is unsolvable, 0 possible soultions at position: ", x, ", ",y)
                    shortesetPossible = possibilitytemp2
                    shortestPosition = [x, y]
                    break mainLoop;
                }
                else
                {
                    shortesetPossible = possibilitytemp2
                    shortestPosition = [x, y]
                    input[x][y] = possibilitytemp2[0]
                    break mainLoop;
                }
            }
        x += 1;
        }
    x = 0
    y += 1;
    }
    return(input, shortestPosition, shortesetPossible)
}

func isSolved(input: Array<Array<Int>>) -> Bool
{
    var isFinished = true;
    var x = 0;
    var y = 0;
    while (y < 9)
    {
        while (x < 9)
        {
            if (input[x][y] == 0)
            {
                isFinished = false;
            }
            x += 1;
        }
        x = 0
        y += 1;
    }
    return(isFinished);
}

func QBoxCheck(input: Array<Array<Int>>, X: Int, Y: Int, possibility: Array<Int>) -> Array<Int>
{
    var box = [0,0];
    var possibility = possibility;
    if (0...2).contains(X)
    {
        if (0...2).contains(Y)
        {
            //top left
            box = [0,0];
        }
        if (3...5).contains(Y)
        { 
            //middle left
            box = [0,3]
        }
        if (6...8).contains(Y)
        {
            //bottom left
            box = [0,6]
        }
    }
    if (3...5).contains(X)
    {
        if (0...2).contains(Y)
        {
            //top middle
            box = [3,0]

        }
        if (3...5).contains(Y)
        {
            //middle middle
            box = [3,3]
        }
        if (6...8).contains(Y)
        {  
            //bottom middle
            box = [3,6]

        }
    }
    if (6...8).contains(X)
    {
        if (0...2).contains(Y)
        {
            //top right 
            box = [6,0]
        }
        if (3...5).contains(Y)
        {
            //middle right 
            box = [6,3]
        }
        if (6...8).contains(Y)
        {
            //bottom right
            box = [6,6]
        }
    }


    var x = 0
    var y = 0
    var temp = 0

    while(y < 3)
    {
        while(x < 3)
        {
            temp = input[x + box[0]][y + box[1]]
            if (temp != 0)
            {
                possibility[temp - 1] = 0
            }
            x += 1;
        }
        x = 0
        y += 1;
    }
    return(possibility)
}

func QVCheck(input: Array<Array<Int>>, X: Int, Y: Int, possibility: Array<Int>) -> Array<Int>
{

    var possibility = possibility;
    var i = 0;
    var temp = 0;
    while (i < 9)
    {
        temp = input[X][i]
        if (temp != 0)
        {
            possibility[temp - 1] = 0
        }
        i += 1
    }

    return(possibility)
}

func QHCheck(input: Array<Array<Int>>, X: Int, Y: Int, possibility: Array<Int>) -> Array<Int>
{
    var possibility = possibility;
    var i = 0;
    var temp = 0;
    while (i < 9)
    {
        temp = input[i][Y]
        if (temp != 0)
        {
            possibility[temp - 1] = 0
        }
        i += 1
    }

    return(possibility)
}



//gameplay loop
while (true)
{
    let originalString = Menu();
    let originalArray = StringToArray(input: originalString);
    Solve(input: originalArray);
    let wait = readLine();
}



