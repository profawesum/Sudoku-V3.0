

import Foundation

public class Grid{


public func DrawGrid(view: String)
{
    print(view)
    var i = 1;
    var once =  true;
    while ( i < 82)
    {
        if (view.count > i)
        {
            var temp = CharacterPosition(i, view);

            if (temp == "0")
            {
                temp = " ";
            }
            print(temp, terminator:"");
        }
        else 
        {
            print(" ", terminator:"");

        }
        if (once == true)
        {
            once = false;
        }
        else
        {
            if (i % 9 == 0)
            {
                print("");
            }
        }

        if (i % 9  == 3 || i % 9  == 6)
        {
           print("|" , terminator:""); 
        }
        if (i == 27 || i == 54)
        {
            print("-----------");
        }
        i+=1;
    }
}

}