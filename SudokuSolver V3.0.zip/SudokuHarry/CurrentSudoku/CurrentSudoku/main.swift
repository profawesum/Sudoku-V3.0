
import Foundation

//gets the position of the character
func CharacterPosition(_ pos: Int,_ from: String) -> Character{
    let temp = from
    let index = temp.index(temp.startIndex, offsetBy: pos)
    return (temp[index])
}


//draws the grid
func DrawGrid(view: String){
    //adds a line in between each iteration of the puzzle
    print(" ")
    var i = 1
    //while there is still space in the grid of 9x9
    while ( i < 82){
        switch view{
            case _ where view.count > i:
                var temp = CharacterPosition(i, view)
            
                if (temp == "0"){
                    temp = " "
                }
                print(temp, terminator:"")
            default:
                print(" ", terminator:"")
        }
        if (i % 9 == 0){
            print("")
        }
        
        if (i % 9  == 3 || i % 9  == 6){
            print("|" , terminator:"")
        }
        if (i == 27 || i == 54){
            print("-----------")
        }
        i+=1
    }
}


//used to solve the puzzle that
//takes a 2D array and outputs a string
func Solve(input: Array<Array<Int>>) -> (String){
    var input = input
    var diff = 0
    
    //while the puzzle is not solved
    while (isSolved(input: &input) != true){
        let input1 = input
        //move to the search function
        let ans = Search(input: &input)
        //set input equal to the return value of input
        //which is an Array<Array<Int>>
        input = ans.0
        //if the shortestPossibility == 0
        //position = Array<Int>
        if (ans.2.count == 0){
            break
        }
        //draw the grid with the current array
        DrawGrid(view: ArrayToString(input: input))
        
        //checks to see if the new input equals the old input
        if (input == input1){
            //add to the difference
            diff += 1
        }
        //if the new input != old input reset the difference
        else{
            diff = 0
        }
        //if difference is greater or equal to 2
        if (diff >= 2){
            //set tempDepth to the value returned from Depth
            let tempDepth = Depth(input: &input, ans: ans)
            //if the depth search returns true
            if (tempDepth.1 == true){
                //input = Array<Array<Int>> from Depth()
                input = tempDepth.0
                break
            }
            //difference reset to 0
            diff = 0
        }
        
    }
    //return the array as a string
    return(ArrayToString(input:input))
}


func Menu() -> String{
    //reset the count for puzzles that cannot be solved if the user inputs values that make it unsolvable
    count = 0
    //get user to input whether they want to input the numbers manually
    print("1) Enter Numbers")
    //or whether they want to auto generate numbers
    print("2) Auto Generate Numbers")
    //gets the input
    let input = readLine()!
    
    //if user inputs 1
    if (input == "1"){
        var i = 0
        var originalString = " "
        var tempString = " "
        
        //while there are still colllumns left to fill run this
        while (i < 9){
            //get the user to input what the value for the row should be
            print("Type the \(i + 1) line (1-9 and 0 being blank)")
            var rowInput = readLine()!
            //if the input is less than 9 then add extra 0's on the end until it reaches 9 values
            while (rowInput.count < 9){
                rowInput.append("0")
            }
            //add the input to the string that the user input
            tempString.append(rowInput)
            //draw the grid to make sure the user is happy with what they input
            DrawGrid(view: tempString)
            //ask if the user wants to re-input the line
            print("\n1) Re-Input Line")
            //if all the collumns have been filled print out the option for solving
            if (i == 8){
                print("2) Solve")
            }
            //otherwise move the user onto the next line
            else{
                print("2) Next Line")
            }
            //get user input
            let input3 = readLine()!
            if (input3 == "1"){
                //if the user wants to re-input the line then
                //set the tempString to the orignalString
                tempString = originalString
            }
            //otherwise if the user inputs 2
            if (input3 == "2"){
                //set the originalString to tempString
                originalString = tempString
                //increment i by 1
                i += 1
            }     
        }
        return(originalString)
        
    }
    //if the user chooses to have it solve a predetermined puzzle of varying difficulty
    if (input == "2"){
        //let the user choose the difficulty of the predertimed puzzle
        var originalString = ""
        print("1) Easy, 2) Medium(one given in brief), 3) Hard, 4) Expert")
        let preDeterminedChoice = readLine()!
        //switch case based on what the user choice is
        switch preDeterminedChoice{
            case "1":
                originalString = " 501627000820090013640000000960401300080730429004900500006075030200369005050000190"
            case "2":
                originalString = " 800406007000000400010000650509030780000070000048020103052000090001000000300902005"
            case "3":
                originalString = " 000000008300000500004300091001046750049000010070005000000400060000081004005000073"
            case "4":
                originalString = " 050809300060000095704000200009201000000000700080600030070000000000107008900002500"
            default:
              print(originalString)
        }
        return(originalString)
    }
    
    return(input)
}


//converts a string to an array
//takes in a string and outputs an Array<Array<Int>>
func StringToArray(input: String) -> Array<Array<Int>>{
    
    var ans = Array(repeating: Array(repeating: 0, count: 9), count: 9)
    var x = 0
    var y = 0
    var count = 1
    
    //while not all collumns have been iterated through
    while (y < 9){
        //while not all rows have been iterated through
        while (x < 9){
            //get the position of the character and assign it to temp1
            let temp = String(CharacterPosition(count, input))
            let temp2 = Int(temp)!
            ans[x][y] = (temp2)
            
            //move to the next item in the string
            count += 1
            //move along the row
            x += 1
        }
        //reset the rows
        x = 0
        //move to the next collumn
        y += 1
    }
    //return the value of ans
    //ans = Array<Array<Int>>
    return(ans)
}

//convert the array to a string
//take in an Array<Array<Int>> and return a string
func ArrayToString(input: Array<Array<Int>>) -> String{
    var ans = " "
    var x = 0 
    var y = 0
    //while not all of the collumns have been iterated through
    while (y < 9){
        //while not all of the rows have been iterated through
        while (x < 9){
            //temp = the value of the inputted array
            var temp = input[x][y]
            temp += 48
            let temp2 = Character(UnicodeScalar(temp)!)
            ans.append(temp2)
            x += 1
        }
        //reset the row value
        x = 0
        //move to the next collumn
        y += 1
    }
    //return the ans as a string
    return(ans)
}

//function to remove zeroes to make it easier to see
//what is happening with the puzzle
//have a blank space instead of a zero to see what spaces are
//empty
func RemoveZeroes(opt: Array<Int>) -> Array<Int>{
    var tempOpt = opt
    var i = opt.count - 1
    while (i > -1){
        //if opt is == 0 then remove the zero
        if (opt[i] == 0){
            tempOpt.remove(at: i)
        }
        //reduce i by 1
        i -= 1
    }
    //return the array
    return(tempOpt)
}


//function for depth search
//takes in an input - Array<Array<Int>> and ans which contains an Array<Array<Int>>(input/mainstring),
//Array<Int>(position) and an Array<Int>(shortestPossibility)
//outputs and Array<Array<Int>> and a bool for success
func Depth(input: inout Array<Array<Int>>, ans : (Array<Array<Int>>, Array<Int>, Array<Int>)) -> (input: Array<Array<Int>>, success: Bool){
    

    var i = 0
    var inputTemp = input
    var diff = 0
    
    //while i is less than the shortest possibility
    while (i < ans.2.count){
        
        inputTemp[ans.1[0]][ans.1[1]] = ans.2[i]
        //make inputTemp1 = inputTemp
        let inputTemp1 = inputTemp
        //set ans to the return of search
        let ans = Search(input: &inputTemp)
        //set imputTemp to mainArray
        inputTemp = ans.0
        //draw the puzzle grid
        DrawGrid(view: ArrayToString(input: inputTemp))
        
        //checks to see if the puzzle has been solved
        if (isSolved(input: &inputTemp) == true){
            //returns inputTemp and success as true
            return(inputTemp, true)
        }
        //if inputTemp = inputTemp1
        if (inputTemp == inputTemp1){
            //add to the difference
            diff += 1
        }
        //otherwise reset difference
        else{
            diff = 0
        }
        //if difference is equal or greater than 2
        if (diff >= 2){
            //call depth again
            let tempDepth = Depth(input: &inputTemp, ans: ans)
            //if tempDepth ans = true
            if (tempDepth.1 == true){
                //return the originalArray and success as true
                return(tempDepth.0, true)
            }
            //increment i by 1
            i += 1
            //reset difference
            diff = 0
            //inputTemp = input
            inputTemp = input
            
        }
    }
    //if it can't find the answer return the 2D Array and success as false
    return(input, false)
    
}

//function that runs through the search
//takes in input which is a 2D array and outputs
//a 2D array, an array of ints and another array of ints
func Search(input: inout Array<Array<Int>>) -> (input: Array<Array<Int>>, position: Array<Int>, shortestPossibility: Array<Int>){
   
    let possibility = [1,2,3,4,5,6,7,8,9]
    var tempPossibility = possibility
    var tempPossibility2 = possibility
    var shortestPossibility = possibility
    var shortestPosition = [0, 0]
    var x = 0
    var y = 0

    mainLoop: while (y < 9){
        while (x < 9){
            if (input[x][y] == 0){
                tempPossibility = possibility
                //see what box it is in
                tempPossibility = WhichBox(input: input, X: x, Y: y, possibility: &tempPossibility)
                tempPossibility2 = RemoveZeroes(opt: tempPossibility)

                switch tempPossibility2{
                    case _ where tempPossibility2.count > 1:
                         //get a vertical check
                        tempPossibility = VerticalCheck(input: input, X: x, Y: y, possibility: &tempPossibility)
                        //removes zeroes
                        tempPossibility2 = RemoveZeroes(opt: tempPossibility)
                            //if the number of values in the tempPossibility2 array > 1
                            if (tempPossibility2.count > 1){
                                //get a horizontal check
                                tempPossibility = HorizontalCheck(input: input, X: x, Y: y, possibility: &tempPossibility)
                                //remove zeroes
                                tempPossibility2 = RemoveZeroes(opt: tempPossibility)
                                //if the number of values in the tempPossibility2 array > 1
                                if (tempPossibility2.count > 1){
                                    //if shortest possibility is greater than tempPossibility
                                    if (shortestPossibility.count > tempPossibility2.count){
                                        //set shortestPossibility to tempPossibility2
                                        shortestPossibility = tempPossibility2
                                        //set the shortestPosition to the current x and y
                                        shortestPosition = [x, y]
                                    }
                                }
                                else{
                                    //get the case to fallthrough if there is an if statement that fails
                                    fallthrough
                                }
                            }
                            else{
                                //get the case to fallthrough if there is an if statement that fails
                                fallthrough
                            }
                    case _ where tempPossibility2.count == 0:
                        //sets there to be no solutions
                        print("No solutions at this point: ", x, ", ",y)
                        count += 1
                        //makes the program stop as the puzzle is unsolvable
                        if(count >= 1000){
                            print("Cannot Solve, Unsolvable puzzle")
                            //return to menu
                            Menu()
                        }
                        //set shortestPossibility to tempPossibility2
                        shortestPossibility = tempPossibility2
                          //set the shortestPosition to the current x and y
                        shortestPosition = [x, y]
                        //break out of the mainLoop
                        break mainLoop
                    
                    default:
                    //set shortestPossibility to tempPossibility2
                        shortestPossibility = tempPossibility2
                          //set the shortestPosition to the current x and y
                        shortestPosition = [x, y]
                        //sets input to the value of tempPossibility2 at the 0th value
                        input[x][y] = tempPossibility2[0]
                        //break out of the main loop
                        break mainLoop
                }
            }
            //increment x
            x += 1
        }
        //reset x
        x = 0
        //increment y
        y += 1
    }
    //return 2D array and 2 Arrays of ints
    return(input, shortestPosition, shortestPossibility)
}


//Checks to see if the sudoku puzzle has been solved
//returns either true or false based on whether or not
//the puzzle has been solved
func isSolved(input: inout Array<Array<Int>>) -> Bool{
    //bool to see if the puzzle has been finished
    var isFinished = true
    var x = 0
    var y = 0
    //checks collumms
    while (y < 9){
        //checks rows
        while (x < 9){
            //checks to see if there are any empty spaces
            if (input[x][y] == 0){
                //if there are any empty spaces then isFinished is set to false
                isFinished = false
            }
            //check next value in the row
            x += 1
        }
        //reset row value back to the first one
        x = 0
        //move to the next collumn
        y += 1
    }
    //return whether the puzzle is finished or not
    return(isFinished)
}

//Checks to see which box it is
//Basically which mini 3x3 grid the current value is in
func WhichBox(input: Array<Array<Int>>, X: Int, Y: Int, possibility: inout Array<Int>) -> Array<Int>{
    var box = [0,0]
    //left most boxes
    if (0...2).contains(X){
        //checks to see if it is the top left box
        if (0...2).contains(Y){
            box = [0,0]
        }
        //checks to see if it is the middle left box
        if (3...5).contains(Y){
            box = [0,3]
        }
        //checks to see if it is the bottom left box
        if (6...8).contains(Y){
            box = [0,6]
        }
    }
    //middle row boxes
    if (3...5).contains(X){
        //checks to see if it is the top center box
        if (0...2).contains(Y){
            box = [3,0]
        }
        //checks to see if it is the middle box
        if (3...5).contains(Y){
            box = [3,3]
        }
        //checks to see if it is the center bottom box
        if (6...8).contains(Y){
            box = [3,6]
        }
    }
    //right most boxes
    if (6...8).contains(X){
        //checks to see if it is the top right box
        if (0...2).contains(Y){
            box = [6,0]
        }
        //checks to see if it is the right middle box
        if (3...5).contains(Y){
            box = [6,3]
        }
        //checks to see if it is the bottom right box
        if (6...8).contains(Y){
            box = [6,6]
        }
    }
    
    
    var x = 0
    var y = 0
    var temp = 0
    //while there are still collumns
    while(y < 3){
        //while there is still value in the row
        while(x < 3){
            temp = input[x + box[0]][y + box[1]]
            if (temp != 0){
                possibility[temp - 1] = 0
            }
            //move to the next value in the row
            x += 1
        }
        //reset row value
        x = 0
        //move to the next collumn
        y += 1
    }
    //return possibility Array<Int>
    return(possibility)
}

//checks y value to make sure that it can solve
//the puzzle as long as it is a solvable puzzle
func VerticalCheck(input: Array<Array<Int>>, X: Int, Y: Int, possibility: inout Array<Int>) -> Array<Int>{
    var i = 0
    var temp = 0
    //while i is less than 9
    while (i < 9){
        temp = input[X][i]
        //if temp is not 0
        if (temp != 0){
            possibility[temp - 1] = 0
        }
        //increment i
        i += 1
    }
    //return possibility Array<Int>
    return(possibility)
}

//checks x value to make sure that it can solve
//the puzzle as long as it is a solvable puzzle
func HorizontalCheck(input: Array<Array<Int>>, X: Int, Y: Int, possibility: inout Array<Int>) -> Array<Int>{
    var i = 0
    var temp = 0
    //while i is less than 9
    while (i < 9){
        temp = input[i][Y]
        //if temp is not 0
        if (temp != 0){
            possibility[temp - 1] = 0
        }
        //increment i
        i += 1
    }
    //return possibility Array<Int>
    return(possibility)
}


//used in case the user inputs an impossible puzzle
var count = 0

//gameplay loop
//makes it so the program will always run
while (true){  
    let originalString = Menu()
    let originalArray = StringToArray(input: originalString)
    Solve(input: originalArray)
    let _ = readLine()
}